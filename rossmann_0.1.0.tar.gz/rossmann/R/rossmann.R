
rossmann <- function(StoreId,DayOfWeek,Date,Promo,Open,SchoolHoliday,StoreType,Assortment,CompetitionDistance,
                  CompetitionOpenSinceYear,CompetitionOpenSinceMonth,Promo2,Promo2SinceYear,Promo2SinceWeek,PromoInterval){

  #newdata <- exp(predict.gam(model, data.matrix(input))) -1
  #return(newdata)

  list(
    message = StoreId)
}
